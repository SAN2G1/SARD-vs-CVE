/**
 * CondorScheddLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package condor;

public class CondorScheddLocator extends org.apache.axis.client.Service implements condor.CondorSchedd {

/**
 * gSOAP 2.7.6c generated service definition
 */

    public CondorScheddLocator() {
    }


    public CondorScheddLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public CondorScheddLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for condorSchedd
    private java.lang.String condorSchedd_address = "http://localhost:80";

    public java.lang.String getcondorScheddAddress() {
        return condorSchedd_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String condorScheddWSDDServiceName = "condorSchedd";

    public java.lang.String getcondorScheddWSDDServiceName() {
        return condorScheddWSDDServiceName;
    }

    public void setcondorScheddWSDDServiceName(java.lang.String name) {
        condorScheddWSDDServiceName = name;
    }

    public condor.CondorScheddPortType getcondorSchedd() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(condorSchedd_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getcondorSchedd(endpoint);
    }

    public condor.CondorScheddPortType getcondorSchedd(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            condor.CondorScheddStub _stub = new condor.CondorScheddStub(portAddress, this);
            _stub.setPortName(getcondorScheddWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setcondorScheddEndpointAddress(java.lang.String address) {
        condorSchedd_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (condor.CondorScheddPortType.class.isAssignableFrom(serviceEndpointInterface)) {
                condor.CondorScheddStub _stub = new condor.CondorScheddStub(new java.net.URL(condorSchedd_address), this);
                _stub.setPortName(getcondorScheddWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("condorSchedd".equals(inputPortName)) {
            return getcondorSchedd();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("urn:condor", "condorSchedd");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("urn:condor", "condorSchedd"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("condorSchedd".equals(portName)) {
            setcondorScheddEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
