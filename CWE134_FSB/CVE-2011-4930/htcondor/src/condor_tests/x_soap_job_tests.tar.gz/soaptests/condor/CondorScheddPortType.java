/**
 * CondorScheddPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package condor;

public interface CondorScheddPortType extends java.rmi.Remote {

    /**
     * Service definition of function condor__getVersionString
     */
    public condor.StringAndStatus getVersionString() throws java.rmi.RemoteException;

    /**
     * Service definition of function condor__getPlatformString
     */
    public condor.StringAndStatus getPlatformString() throws java.rmi.RemoteException;

    /**
     * Service definition of function condor__beginTransaction
     */
    public condor.TransactionAndStatus beginTransaction(int duration) throws java.rmi.RemoteException;

    /**
     * Service definition of function condor__commitTransaction
     */
    public condor.Status commitTransaction(condor.Transaction transaction) throws java.rmi.RemoteException;

    /**
     * Service definition of function condor__abortTransaction
     */
    public condor.Status abortTransaction(condor.Transaction transaction) throws java.rmi.RemoteException;

    /**
     * Service definition of function condor__extendTransaction
     */
    public condor.TransactionAndStatus extendTransaction(condor.Transaction transaction, int duration) throws java.rmi.RemoteException;

    /**
     * Service definition of function condor__newCluster
     */
    public condor.IntAndStatus newCluster(condor.Transaction transaction) throws java.rmi.RemoteException;

    /**
     * Service definition of function condor__removeCluster
     */
    public condor.Status removeCluster(condor.Transaction transaction, int clusterId, java.lang.String reason) throws java.rmi.RemoteException;

    /**
     * Service definition of function condor__newJob
     */
    public condor.IntAndStatus newJob(condor.Transaction transaction, int clusterId) throws java.rmi.RemoteException;

    /**
     * Service definition of function condor__removeJob
     */
    public condor.Status removeJob(condor.Transaction transaction, int clusterId, int jobId, java.lang.String reason, boolean forceRemoval) throws java.rmi.RemoteException;

    /**
     * Service definition of function condor__holdJob
     */
    public condor.Status holdJob(condor.Transaction transaction, int clusterId, int jobId, java.lang.String reason, boolean emailUser, boolean emailAdmin, boolean systemHold) throws java.rmi.RemoteException;

    /**
     * Service definition of function condor__releaseJob
     */
    public condor.Status releaseJob(condor.Transaction transaction, int clusterId, int jobId, java.lang.String reason, boolean emailUser, boolean emailAdmin) throws java.rmi.RemoteException;

    /**
     * Service definition of function condor__submit
     */
    public condor.RequirementsAndStatus submit(condor.Transaction transaction, int clusterId, int jobId, condor.ClassAdStructAttr[] jobAd) throws java.rmi.RemoteException;

    /**
     * Service definition of function condor__getJobAds
     */
    public condor.ClassAdStructArrayAndStatus getJobAds(condor.Transaction transaction, java.lang.String constraint) throws java.rmi.RemoteException;

    /**
     * Service definition of function condor__getJobAd
     */
    public condor.ClassAdStructAndStatus getJobAd(condor.Transaction transaction, int clusterId, int jobId) throws java.rmi.RemoteException;

    /**
     * Service definition of function condor__declareFile
     */
    public condor.Status declareFile(condor.Transaction transaction, int clusterId, int jobId, java.lang.String name, int size, condor.HashType hashType, java.lang.String hash) throws java.rmi.RemoteException;

    /**
     * Service definition of function condor__sendFile
     */
    public condor.Status sendFile(condor.Transaction transaction, int clusterId, int jobId, java.lang.String name, int offset, byte[] data) throws java.rmi.RemoteException;

    /**
     * Service definition of function condor__getFile
     */
    public condor.Base64DataAndStatus getFile(condor.Transaction transaction, int clusterId, int jobId, java.lang.String name, int offset, int length) throws java.rmi.RemoteException;

    /**
     * Service definition of function condor__closeSpool
     */
    public condor.Status closeSpool(condor.Transaction transaction, int clusterId, int jobId) throws java.rmi.RemoteException;

    /**
     * Service definition of function condor__listSpool
     */
    public condor.FileInfoArrayAndStatus listSpool(condor.Transaction transaction, int clusterId, int jobId) throws java.rmi.RemoteException;

    /**
     * Service definition of function condor__requestReschedule
     */
    public condor.Status requestReschedule() throws java.rmi.RemoteException;

    /**
     * Service definition of function condor__discoverJobRequirements
     */
    public condor.RequirementsAndStatus discoverJobRequirements(condor.ClassAdStructAttr[] jobAd) throws java.rmi.RemoteException;

    /**
     * Service definition of function condor__createJobTemplate
     */
    public condor.ClassAdStructAndStatus createJobTemplate(int clusterId, int jobId, java.lang.String owner, condor.UniverseType type, java.lang.String cmd, java.lang.String args, java.lang.String requirements) throws java.rmi.RemoteException;
}
