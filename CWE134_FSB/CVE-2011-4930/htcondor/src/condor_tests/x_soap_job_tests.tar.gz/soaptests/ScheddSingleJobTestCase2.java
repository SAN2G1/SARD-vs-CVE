import birdbath.Transaction;
import condor.UniverseType;
import java.io.File;
import java.io.FileOutputStream;
import junit.framework.AssertionFailedError;

public class ScheddSingleJobTestCase2
	extends AbstractScheddSingleJobTestCase
{
	private File sourceFile;
	private File destinationFile;

	protected void submitJob(Transaction transaction,
							 int cluster,
							 int job,
							 String owner)
		throws Throwable
	{
		transaction.submit(cluster,
						   job,
						   owner,
						   UniverseType.VANILLA,
						   "/bin/sleep",
						   "30",
						   "OpSys != \"WINNT50\"",
						   null,
						   null);
	}

	protected void jobFinished(Transaction transaction,
							   int cluster,
							   int job)
		throws Throwable
	{
	}
}
